import React, { useRef,useState,useEffect } from 'react';
import axios from 'axios';

import {
    MDBInput,
    MDBCol,
    MDBRow,
    MDBCheckbox,
    MDBBtn
} from 'mdb-react-ui-kit';
import { useNavigate, useParams } from 'react-router';


const UpdateProduct = () => {


    const BASE_URL = 'https://localhost:7204'


    const {id} = useParams();

    const nav = useNavigate();

    const prodName = useRef();
    const prodPrice = useRef();
    const prodDesc = useRef();

    console.log(id)



    async function getProducts() {
        try {
            const response = await axios.get(`${BASE_URL}/api/Product/fetch/${id}`);

           prodName.current.value = response.data.prodName
           prodPrice.current.value = response.data.prodPrice
           prodDesc.current.value = response.data.prodDesc
            console.log(response);
        } catch (error) {
            console.error(error);
        }
    }


    useEffect(() => {
        getProducts();
    }, [])




    async function updateHandler(e){
        e.preventDefault();

       try {
         // console.log(prodName.current.value)
         const { data } = await axios.put(`${BASE_URL}/api/Product`, {
            id: id,
            prodName: prodName.current.value,
            prodPrice: prodPrice.current.value,
            prodDesc: prodDesc.current.value
        })

        nav('/')
       } catch (error) {
        console.error(error)
       }

    }






  return (
    <>
    
    <h1 className='text-center'>Update Products</h1>

<div className="container">
    <div className="row">
        <form>
            <MDBInput className='mb-4' ref={prodName} type='text' id='form1Example1' />
            <MDBInput className='mb-4' ref={prodPrice} type='text' id='form1Example2' />
            <MDBInput className='mb-4' ref={prodDesc} type='text' id='form1Example2' />



            <MDBBtn type='submit' block onClick={updateHandler}>
                Update Product
            </MDBBtn>
        </form>
    </div>
</div>

    
    </>
  )
}

export default UpdateProduct