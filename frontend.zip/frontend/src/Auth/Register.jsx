import React, { useState } from 'react';
import {
    MDBValidation,
    MDBValidationItem,
    MDBInput,
    MDBBtn,
} from 'mdb-react-ui-kit';
import axios from 'axios';


export default function Register() {

    const BASE_URL = 'https://localhost:7204'
    const [formValue, setFormValue] = useState({
        Username: '',
        Email: '',
        PasswordHash: '',
        Role: 'User'
    });

    const onChange = (e) => {
        setFormValue({ ...formValue, [e.target.name]: e.target.value });
        console.log(formValue)
    };


    const registerHandler = async (e) => {
        e.preventDefault();
        try {
            const { data } = await axios.post(`${BASE_URL}/api/Auth/register`, formValue)
            console.log(data)
            console.log('Registration successfull')
        } catch (error) {
            console.log(error)
        }
    }



    return (
        <>
            <div className="container mt-5">
                <MDBValidation className='row g-3'>
                    <MDBValidationItem className='col-md-12'>
                        <MDBInput
                            value={formValue.Username}
                            name='Username'
                            onChange={onChange}

                            required
                            label='User Name'
                        />
                    </MDBValidationItem>
                    <MDBValidationItem className='col-md-12'>
                        <MDBInput
                            value={formValue.Email}
                            name='Email'
                            onChange={onChange}

                            required
                            label='Email'
                        />
                    </MDBValidationItem>
                    <MDBValidationItem className='col-md-12'>
                        <MDBInput
                            value={formValue.PasswordHash}
                            name='PasswordHash'
                            onChange={onChange}

                            required
                            label='Password'
                        />
                    </MDBValidationItem>


                    <div className='col-12'>
                        <MDBBtn type='submit' onClick={registerHandler}>Submit form</MDBBtn>
                    </div>
                </MDBValidation>
            </div>


        </>
    );
}