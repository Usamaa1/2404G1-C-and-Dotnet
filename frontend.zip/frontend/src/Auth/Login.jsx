import React, { useState } from 'react';
import {
    MDBValidation,
    MDBValidationItem,
    MDBInput,
    MDBBtn,
} from 'mdb-react-ui-kit';
import axios from 'axios';


export default function Login() {

    const BASE_URL = 'https://localhost:7204'
    const [formValue, setFormValue] = useState({
        Email: '',
        PasswordHash: '',
    });

    const onChange = (e) => {
        setFormValue({ ...formValue, [e.target.name]: e.target.value });
        console.log(formValue)
    };


    const loginHandler = async (e) => {
        e.preventDefault();
        try {
            const { data } = await axios.post(`${BASE_URL}/api/Auth/login`, formValue)
            console.log(data.token)

            localStorage.setItem('userToken',data.token)
            console.log('Login Successfull')
        } catch (error) {
            console.log(error)
        }
    }



    return (
        <>
            <div className="container mt-5">
                <MDBValidation className='row g-3'>
                    <MDBValidationItem className='col-md-12'>
                        <MDBInput
                            value={formValue.Email}
                            name='Email'
                            onChange={onChange}

                            required
                            label='Email'
                        />
                    </MDBValidationItem>
                    <MDBValidationItem className='col-md-12'>
                        <MDBInput
                            value={formValue.PasswordHash}
                            name='PasswordHash'
                            onChange={onChange}

                            required
                            label='Password'
                        />
                    </MDBValidationItem>


                    <div className='col-12'>
                        <MDBBtn type='submit' onClick={loginHandler}>Login</MDBBtn>
                    </div>
                </MDBValidation>
            </div>


        </>
    );
}