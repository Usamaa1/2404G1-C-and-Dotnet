import React from 'react'
import { Outlet } from 'react-router';
import { MyNavbar } from './MyNavbar';



 const App = () => {
  return (
    <>
    
    <MyNavbar></MyNavbar>
    <Outlet></Outlet>



    
    
    </>




  )
}
export default App;