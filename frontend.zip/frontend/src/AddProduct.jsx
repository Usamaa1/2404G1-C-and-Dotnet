import React, { useRef } from 'react';
import axios from 'axios';

import {
    MDBInput,
    MDBCol,
    MDBRow,
    MDBCheckbox,
    MDBBtn
} from 'mdb-react-ui-kit';

const AddProduct = () => {

    const BASE_URL = 'https://localhost:7204'

    const prodName = useRef();
    const prodPrice = useRef();
    const prodDesc = useRef();




    const addProdHandler = async (e) => {
        e.preventDefault();

        console.log(prodName.current.value)
        const { data } = await axios.post(`${BASE_URL}/api/Product`, {
            prodName: prodName.current.value,
            prodPrice: prodPrice.current.value,
            prodDesc: prodDesc.current.value
        })
    }








    return (
        <>
            <h1 className='text-center'>Add Products</h1>

            <div className="container">
                <div className="row">
                    <form>
                        <MDBInput className='mb-4' ref={prodName} type='text' id='form1Example1' label='Product Name' />
                        <MDBInput className='mb-4' ref={prodPrice} type='text' id='form1Example2' label='Product Price' />
                        <MDBInput className='mb-4' ref={prodDesc} type='text' id='form1Example2' label='Product Description' />



                        <MDBBtn type='submit' block onClick={addProdHandler}>
                            Add Product
                        </MDBBtn>
                    </form>
                </div>
            </div>

        </>
    )
}

export default AddProduct