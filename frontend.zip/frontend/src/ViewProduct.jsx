import React, { useEffect, useRef, useState } from 'react'
import axios from 'axios';
import {
    MDBCard,
    MDBCardBody,
    MDBCardTitle,
    MDBCardText,
    MDBBtn
} from 'mdb-react-ui-kit';
import { useNavigate } from 'react-router';










const ViewProduct = () => {



    const BASE_URL = 'https://localhost:7204'


    const [productsData, setProductsData] = useState([]);

    const updateRef = useNavigate();

    async function getProducts() {
        try {
            const response = await axios.get(`${BASE_URL}/api/Product`);

            setProductsData(response.data)
            console.log(response);
        } catch (error) {
            console.error(error);
        }
    }


    useEffect(() => {
        getProducts();
    }, [])




    const prodDeleteHandler = async (id) => {
        try {
            await axios.delete(`${BASE_URL}/api/Product/${id}`)
        } catch (error) {
            console.log(error)
        }
    }



    const searchQuery = useRef();


    const searchHandler = async (e)=>{
        e.preventDefault();
        try {
            const response = await axios.get(`${BASE_URL}/api/Product/${searchQuery.current.value}`);

            setProductsData(response.data)
            console.log(response);
        } catch (error) {
            console.error(error);
        }



    }











    return (
        <>

            <h1 className='text-center'>View Products</h1>

            <div className="container">
                <div className="row">
                    <div className="col-md-12 my-3">
                        <form className='d-flex input-group w-auto'>
                            <input type='search' className='form-control' ref={searchQuery} placeholder='Type query' aria-label='Search' />
                            <MDBBtn color='primary' onClick={searchHandler}>Search</MDBBtn>
                        </form>

                    </div>

                </div>
            </div>

            <div className="container">
                <div className="row">


                    {
                        console.log("HTML PRODUCTS", productsData)
                    }
                    {



                        productsData.map((prod) => (
                            <div className="col-4" key={prod.id}>

                                <MDBCard>
                                    <MDBCardBody>
                                        <MDBCardTitle>{prod.prodName}</MDBCardTitle>
                                        <MDBCardText>
                                            {prod.prodDesc}
                                        </MDBCardText>
                                        <MDBBtn color='danger' onClick={() => prodDeleteHandler(prod.id)}>Delete</MDBBtn>
                                        <MDBBtn color='warning' onClick={() => updateRef(`/updateProduct/${prod.id}`)}>Update</MDBBtn>
                                    </MDBCardBody>
                                </MDBCard>
                            </div>



                        ))
                    }




                </div>
            </div>




        </>
    )
}

export default ViewProduct